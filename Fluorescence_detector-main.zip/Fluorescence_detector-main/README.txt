# Fluorescence_detector
Fluorescence detectror 

Related publication:
A low-cost fluorescence reader for in vitro transcription and nucleic acid detection with Cas13a
 
Authors of this publication:
Florian Katzmeier, Lukas Aufinger, Aurore Dupin, Jorge Quinteiro, Matthias, Lenz, Ludwig Bauer, Sven Klumpe, Dawafuti Sherpa, Benedikt Dürr , Maximilian Honemann, Igor Styazhkin, Friedrich C. Simmel, Michael Heymann

The .stl files should be oriented for print such that the flattest side of each part is on the bottom. The spacer file needs to be printed twice.

For running the software, please check the README file first.


Information on the assembly can be found in the supplementary infromation of the publication.
