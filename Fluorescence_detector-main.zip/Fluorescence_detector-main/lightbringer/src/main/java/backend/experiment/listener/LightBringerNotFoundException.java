package backend.experiment.listener;

public class LightBringerNotFoundException extends Exception {

    public LightBringerNotFoundException(String message){
        super(message);
    }
}
