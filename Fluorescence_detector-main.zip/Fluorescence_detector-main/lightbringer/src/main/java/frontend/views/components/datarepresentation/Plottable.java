package frontend.views.components.datarepresentation;

public interface Plottable {

    double getXValue();

    double getYValue();
}
