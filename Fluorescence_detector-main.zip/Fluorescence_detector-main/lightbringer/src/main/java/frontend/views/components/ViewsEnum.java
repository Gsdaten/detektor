package frontend.views.components;

public enum ViewsEnum {

    START_MENU,

    CONCENTRATION_MENU,

    CALIBRATION_MENU,

    CONCETRATION_VIEW,

    CALIBRATION_VIEW,

    TABLE_VIEW,

    PLOT_VIEW

}
