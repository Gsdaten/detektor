The arduino sketch in the AdruinoSketch_new folder needs to be uploaded on the microcontroller. Use the Arduino developement software to do that. https://www.arduino.cc/en/main/software
If this version cause trouble try using the one in the AdruinoSketch_old folder

The Lighbringer.jar can then be excecuted while the microcontroller is connected to operate the detector. You need the Java Runtime Enviroment for that. https://java.com/de/download/
